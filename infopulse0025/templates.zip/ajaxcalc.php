<?
//header('HTTP/1.1 403 Forbidden')
include("calc.php");
//sleep(5);
?>